//
//  W06_PracticeTests.swift
//  W06_PracticeTests
//
//  Created by student on 16/10/25.
//

import Testing
@testable import W06_Practice

struct W06_PracticeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
