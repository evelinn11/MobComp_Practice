//
//  W05_PracticeTests.swift
//  W05_PracticeTests
//
//  Created by student on 09/10/25.
//

import Testing
@testable import W05_Practice

struct W05_PracticeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
