//
//  W05_PracticeApp.swift
//  W05_Practice
//
//  Created by student on 09/10/25.
//

import SwiftUI

@main
struct W05_PracticeApp: App {
    var body: some Scene {
        WindowGroup {
            MovieHomeView()
        }
    }
}
