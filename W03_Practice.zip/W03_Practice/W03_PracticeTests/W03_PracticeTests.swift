//
//  W03_PracticeTests.swift
//  W03_PracticeTests
//
//  Created by student on 25/09/25.
//

import Testing
@testable import W03_Practice

struct W03_PracticeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
