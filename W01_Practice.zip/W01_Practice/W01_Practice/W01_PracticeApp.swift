//
//  W01_PracticeApp.swift
//  W01_Practice
//
//  Created by student on 11/09/25.
//

import SwiftUI

@main
struct W01_PracticeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
